export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { cleanCNPJ, validateCNPJ } from "@/lib/utils/cnpj";

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const body = await request.json();
    const { cnpj } = body ?? {};

    const cleanedCnpj = cleanCNPJ(cnpj ?? "");

    if (!validateCNPJ(cleanedCnpj)) {
      return NextResponse.json(
        { valid: false, error: "CNPJ inválido" },
        { status: 200 }
      );
    }

    const existingCompany = await prisma.company.findUnique({
      where: { cnpj: cleanedCnpj },
      include: {
        leads: {
          where: { status: { not: "ENCERRADA" } },
          include: {
            responsavel: { select: { name: true } },
          },
          take: 1,
        },
      },
    });

    if (existingCompany && existingCompany.leads.length > 0) {
      const lead = existingCompany.leads[0];
      return NextResponse.json({
        valid: true,
        exists: true,
        company: {
          razaoSocial: existingCompany.razaoSocial,
          nomeFantasia: existingCompany.nomeFantasia,
        },
        lead: {
          id: lead?.id,
          status: lead?.status,
          responsavel: lead?.responsavel?.name,
        },
      });
    }

    return NextResponse.json({
      valid: true,
      exists: false,
      company: existingCompany
        ? {
            razaoSocial: existingCompany.razaoSocial,
            nomeFantasia: existingCompany.nomeFantasia,
          }
        : null,
    });
  } catch (error) {
    console.error("Erro ao verificar CNPJ:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
