export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission, canAccessLead } from "@/lib/permissions";
import { cleanCNPJ, validateCNPJ } from "@/lib/utils/cnpj";
import { cleanPhone } from "@/lib/utils/phone";
import { calculateLeadScore } from "@/lib/utils/lead-score";

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const page = parseInt(searchParams.get("page") ?? "1");
    const limit = parseInt(searchParams.get("limit") ?? "20");
    const responsavelId = searchParams.get("responsavelId");
    const search = searchParams.get("search");
    const prospeccao = searchParams.get("prospeccao"); // Filtro para prospecções

    const where: any = {};

    // Filtro por permissão baseado no novo sistema RBAC
    if (user.role === "ADMIN") {
      // Admin vê todos os leads
    } else if (user.role === "GERENTE") {
      // Gerente vê apenas leads atribuídos a ele ou sua prospecção
      where.OR = [
        { responsavelId: user.id },
        { AND: [{ registradorId: user.id }, { isProspeccao: true }] },
      ];
    } else if (user.role === "ALIADO") {
      // Aliado vê apenas leads que registrou
      where.registradorId = user.id;
    }

    if (status) where.status = status;
    if (responsavelId) where.responsavelId = responsavelId;
    if (prospeccao === "true") where.isProspeccao = true;
    if (search) {
      const searchCondition = {
        OR: [
          { company: { razaoSocial: { contains: search, mode: "insensitive" } } },
          { company: { cnpj: { contains: cleanCNPJ(search) } } },
          { contact: { name: { contains: search, mode: "insensitive" } } },
        ],
      };
      // Combinar com filtros existentes
      if (where.OR) {
        where.AND = [{ OR: where.OR }, searchCondition];
        delete where.OR;
      } else {
        where.OR = searchCondition.OR;
      }
    }

    const [leads, total] = await Promise.all([
      prisma.lead.findMany({
        where,
        include: {
          company: true,
          contact: true,
          registrador: { select: { id: true, name: true, email: true } },
          responsavel: { select: { id: true, name: true, email: true } },
          _count: { select: { interactions: true } },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.lead.count({ where }),
    ]);

    return NextResponse.json({
      data: leads,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Erro ao listar leads:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    
    // Verificar permissão de criar lead ou prospecção
    const canCreateLead = hasPermission(user.role, "lead:create");
    const canCreateProspeccao = hasPermission(user.role, "prospeccao:create");
    
    if (!canCreateLead && !canCreateProspeccao) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const body = await request.json();
    const {
      cnpj,
      razaoSocial,
      nomeFantasia,
      city,
      state,
      segment,
      size,
      contactName,
      contactEmail,
      contactPhone,
      contactPosition,
      consentimento,
      source,
      necessity,
      urgency,
      notes,
      imageUrl,
      isProspeccao,
    } = body ?? {};

    const cleanedCnpj = cleanCNPJ(cnpj ?? "");
    if (!validateCNPJ(cleanedCnpj)) {
      return NextResponse.json({ error: "CNPJ inválido" }, { status: 400 });
    }

    if (!razaoSocial || !contactName || !contactPhone) {
      return NextResponse.json(
        { error: "Razão social, nome e telefone do contato são obrigatórios" },
        { status: 400 }
      );
    }

    // Verificar duplicata
    const existingCompany = await prisma.company.findUnique({
      where: { cnpj: cleanedCnpj },
      include: { leads: { include: { responsavel: true } } },
    });

    if (existingCompany && existingCompany.leads.length > 0) {
      const activeLead = existingCompany.leads.find(
        (l) => l.status !== "ENCERRADA" && l.status !== "INATIVO"
      );
      if (activeLead) {
        return NextResponse.json(
          {
            error: "Empresa já possui lead ativo",
            existingLead: {
              id: activeLead.id,
              status: activeLead.status,
              responsavel: activeLead.responsavel?.name,
            },
          },
          { status: 409 }
        );
      }
    }

    // Calcular lead score
    const leadScore = calculateLeadScore({
      hasEmail: !!contactEmail,
      hasPhone: !!contactPhone,
      hasSegment: !!segment,
      hasSize: !!size,
      hasNecessity: !!necessity,
      hasUrgency: !!urgency,
      hasConsent: !!consentimento,
      urgency: urgency ?? undefined,
      segmentFit: ["industria", "comercio", "servicos", "agronegocio"].includes(
        segment ?? ""
      ),
      sizeFit: ["PEQUENA", "MEDIA"].includes(size ?? ""),
    });

    // Determinar se é prospecção (Gerente criando lead próprio)
    const isProspeccaoLead = user.role === "GERENTE" && isProspeccao;

    // Criar ou atualizar empresa e contato
    const result = await prisma.$transaction(async (tx) => {
      let companyId = existingCompany?.id;
      
      if (!companyId) {
        const newCompany = await tx.company.create({
          data: {
            cnpj: cleanedCnpj,
            razaoSocial,
            nomeFantasia,
            city,
            state,
            segment,
            size,
            consentimento: !!consentimento,
            createdById: user.id,
          },
        });
        companyId = newCompany.id;
      }

      const contact = await tx.contact.create({
        data: {
          companyId,
          name: contactName,
          email: contactEmail,
          phone: cleanPhone(contactPhone ?? ""),
          whatsapp: cleanPhone(contactPhone ?? ""),
          position: contactPosition,
          isPrimary: true,
          consentimento: !!consentimento,
        },
      });

      const lead = await tx.lead.create({
        data: {
          companyId,
          contactId: contact.id,
          registradorId: user.id,
          responsavelId: isProspeccaoLead ? user.id : undefined,
          source,
          necessity,
          urgency,
          notes,
          leadScore,
          imageUrl,
          isProspeccao: isProspeccaoLead,
          status: isProspeccaoLead ? "ATRIBUIDA" : "PENDENTE",
          assignedAt: isProspeccaoLead ? new Date() : undefined,
        },
        include: {
          company: true,
          contact: true,
          registrador: { select: { id: true, name: true, email: true } },
        },
      });

      await tx.statusHistory.create({
        data: {
          leadId: lead.id,
          newStatus: isProspeccaoLead ? "ATRIBUIDA" : "PENDENTE",
          changedById: user.id,
          reason: isProspeccaoLead ? "Prospecção criada" : "Lead criado",
        },
      });

      return lead;
    });

    // Enviar notificação por email (apenas para indicações, não prospecções)
    if (!isProspeccaoLead) {
      try {
        const appUrl = process.env.NEXTAUTH_URL ?? "";
        const appName = "LS Indicação";
        
        const htmlBody = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #1e3a5f; border-bottom: 2px solid #1e3a5f; padding-bottom: 10px;">
              🌟 Nova Indicação Recebida
            </h2>
            <div style="background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Empresa:</strong> ${razaoSocial}</p>
              <p style="margin: 10px 0;"><strong>CNPJ:</strong> ${cnpj}</p>
              <p style="margin: 10px 0;"><strong>Contato:</strong> ${contactName}</p>
              <p style="margin: 10px 0;"><strong>Telefone:</strong> ${contactPhone}</p>
              ${contactEmail ? `<p style="margin: 10px 0;"><strong>Email:</strong> ${contactEmail}</p>` : ""}
              ${segment ? `<p style="margin: 10px 0;"><strong>Segmento:</strong> ${segment}</p>` : ""}
              <p style="margin: 10px 0;"><strong>Score:</strong> ${leadScore}/100</p>
              <p style="margin: 10px 0;"><strong>Registrado por:</strong> ${(session.user as any).name}</p>
            </div>
            <p style="color: #666; font-size: 12px;">
              Submetido em: ${new Date().toLocaleString("pt-BR")}
            </p>
            <a href="${appUrl}/leads/${result.id}" style="display: inline-block; background: #1e3a5f; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-top: 10px;">Ver Indicação</a>
          </div>
        `;

        await fetch("https://apps.abacus.ai/api/sendNotificationEmail", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            deployment_token: process.env.ABACUSAI_API_KEY,
            app_id: process.env.WEB_APP_ID,
            notification_id: process.env.NOTIF_ID_NOVA_INDICAO_RECEBIDA,
            subject: `Nova Indicação: ${razaoSocial}`,
            body: htmlBody,
            is_html: true,
            recipient_email: "arthur@lsinterbank.com.br",
            sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
            sender_alias: appName,
          }),
        });
      } catch (emailError) {
        console.error("Erro ao enviar notificação:", emailError);
      }
    }

    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    console.error("Erro ao criar lead:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
