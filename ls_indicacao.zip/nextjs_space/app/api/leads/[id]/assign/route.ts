export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "lead:assign")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const body = await request.json();
    const { responsavelId, notes } = body ?? {};

    if (!responsavelId) {
      return NextResponse.json(
        { error: "Responsável é obrigatório" },
        { status: 400 }
      );
    }

    const lead = await prisma.lead.findUnique({
      where: { id: params.id },
    });

    if (!lead) {
      return NextResponse.json(
        { error: "Lead não encontrado" },
        { status: 404 }
      );
    }

    // Verificação: Admin e Aliado só podem atribuir leads que eles criaram
    // Gerente não pode atribuir leads (já está na permissão lead:assign)
    if (lead.registradorId !== user.id) {
      return NextResponse.json(
        { error: "Você só pode atribuir leads que você criou" },
        { status: 403 }
      );
    }

    const result = await prisma.$transaction(async (tx) => {
      const updatedLead = await tx.lead.update({
        where: { id: params.id },
        data: {
          responsavelId,
          status: "ATRIBUIDA",
          assignedAt: new Date(),
        },
        include: {
          company: true,
          contact: true,
          responsavel: { select: { id: true, name: true, email: true } },
        },
      });

      await tx.assignment.create({
        data: {
          leadId: params.id,
          assignedToId: responsavelId,
          assignedById: user.id,
          notes,
        },
      });

      await tx.statusHistory.create({
        data: {
          leadId: params.id,
          previousStatus: lead.status,
          newStatus: "ATRIBUIDA",
          changedById: user.id,
          reason: `Atribuído para ${updatedLead.responsavel?.name}`,
        },
      });

      return updatedLead;
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error("Erro ao atribuir lead:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
