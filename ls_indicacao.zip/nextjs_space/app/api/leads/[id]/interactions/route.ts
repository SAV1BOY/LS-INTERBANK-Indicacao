export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission, canAccessLead } from "@/lib/permissions";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const interactions = await prisma.interaction.findMany({
      where: { leadId: params.id },
      include: {
        author: { select: { id: true, name: true } },
      },
      orderBy: { occurredAt: "desc" },
    });

    return NextResponse.json(interactions);
  } catch (error) {
    console.error("Erro ao listar interações:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "interaction:create")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const body = await request.json();
    const {
      type,
      result,
      notes,
      nextStep,
      nextStepDate,
      durationMinutes,
      occurredAt,
    } = body ?? {};

    if (!type) {
      return NextResponse.json(
        { error: "Tipo de interação é obrigatório" },
        { status: 400 }
      );
    }

    const lead = await prisma.lead.findUnique({
      where: { id: params.id },
    });

    if (!lead) {
      return NextResponse.json(
        { error: "Lead não encontrado" },
        { status: 404 }
      );
    }

    if (!canAccessLead(user.role, user.id, lead)) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const result2 = await prisma.$transaction(async (tx) => {
      const interaction = await tx.interaction.create({
        data: {
          leadId: params.id,
          authorId: user.id,
          type,
          result,
          notes,
          nextStep,
          nextStepDate: nextStepDate ? new Date(nextStepDate) : undefined,
          durationMinutes,
          occurredAt: occurredAt ? new Date(occurredAt) : new Date(),
        },
        include: {
          author: { select: { id: true, name: true } },
        },
      });

      // Se for a primeira interação e o status for ATRIBUIDA, mudar para EM_CONTATO
      if (lead.status === "ATRIBUIDA" && !lead.firstContactAt) {
        await tx.lead.update({
          where: { id: params.id },
          data: {
            status: "EM_CONTATO",
            firstContactAt: new Date(),
          },
        });

        await tx.statusHistory.create({
          data: {
            leadId: params.id,
            previousStatus: lead.status,
            newStatus: "EM_CONTATO",
            changedById: user.id,
            reason: "Primeiro contato registrado",
          },
        });
      }

      return interaction;
    });

    return NextResponse.json(result2, { status: 201 });
  } catch (error) {
    console.error("Erro ao criar interação:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
