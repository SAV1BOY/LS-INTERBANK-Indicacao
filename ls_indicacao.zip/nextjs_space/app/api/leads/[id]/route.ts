export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission, canAccessLead } from "@/lib/permissions";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    const lead = await prisma.lead.findUnique({
      where: { id: params.id },
      include: {
        company: true,
        contact: true,
        registrador: { select: { id: true, name: true, email: true } },
        responsavel: { select: { id: true, name: true, email: true } },
        interactions: {
          include: {
            author: { select: { id: true, name: true } },
          },
          orderBy: { occurredAt: "desc" },
        },
        statusHistory: {
          include: {
            changedBy: { select: { id: true, name: true } },
          },
          orderBy: { changedAt: "desc" },
        },
        assignments: {
          include: {
            assignedTo: { select: { id: true, name: true } },
            assignedBy: { select: { id: true, name: true } },
          },
          orderBy: { assignedAt: "desc" },
        },
      },
    });

    if (!lead) {
      return NextResponse.json(
        { error: "Lead não encontrado" },
        { status: 404 }
      );
    }

    if (!canAccessLead(user.role, user.id, lead)) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    return NextResponse.json(lead);
  } catch (error) {
    console.error("Erro ao buscar lead:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    
    // Buscar o lead para verificar permissões
    const existingLead = await prisma.lead.findUnique({
      where: { id: params.id },
      select: { registradorId: true },
    });

    if (!existingLead) {
      return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });
    }

    const body = await request.json();
    const { source, necessity, urgency, notes, imageUrl } = body ?? {};

    // ALIADO pode editar apenas observações dos leads que ele criou
    // ADMIN e GERENTE podem editar todos os campos
    const isOwner = existingLead.registradorId === user.id;
    const canUpdateFull = hasPermission(user.role, "lead:update");
    
    if (!canUpdateFull && !isOwner) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    // Se for ALIADO (não tem lead:update), só pode atualizar notes
    const updateData = canUpdateFull
      ? { source, necessity, urgency, notes, imageUrl }
      : { notes }; // ALIADO só pode atualizar observações

    const lead = await prisma.lead.update({
      where: { id: params.id },
      data: updateData,
      include: {
        company: true,
        contact: true,
        registrador: { select: { id: true, name: true, email: true } },
        responsavel: { select: { id: true, name: true, email: true } },
      },
    });

    return NextResponse.json(lead);
  } catch (error) {
    console.error("Erro ao atualizar lead:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
