export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission, canAccessLead } from "@/lib/permissions";
import { canTransition, getStatusFromCloseReason } from "@/lib/utils/status";
import { LeadStatus, CloseReason } from "@prisma/client";

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "lead:change_status")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const body = await request.json();
    const { status, closeReason, closeReasonDetail } = body ?? {};

    if (!status) {
      return NextResponse.json(
        { error: "Status é obrigatório" },
        { status: 400 }
      );
    }

    const lead = await prisma.lead.findUnique({
      where: { id: params.id },
    });

    if (!lead) {
      return NextResponse.json(
        { error: "Lead não encontrado" },
        { status: 404 }
      );
    }

    if (!canAccessLead(user.role, user.id, lead)) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    // Determinar o status final baseado no close reason
    let finalStatus = status as LeadStatus;
    if ((status === "ENCERRADA" || status === "INATIVO") && closeReason) {
      finalStatus = getStatusFromCloseReason(closeReason as CloseReason);
    }

    if (!canTransition(lead.status, finalStatus)) {
      return NextResponse.json(
        { error: "Transição de status inválida" },
        { status: 400 }
      );
    }

    if ((finalStatus === "ENCERRADA" || finalStatus === "INATIVO") && !closeReason) {
      return NextResponse.json(
        { error: "Motivo de encerramento é obrigatório" },
        { status: 400 }
      );
    }

    const updateData: any = {
      status: finalStatus,
    };

    if (finalStatus === "EM_CONTATO" && !lead.firstContactAt) {
      updateData.firstContactAt = new Date();
    }

    if (finalStatus === "QUALIFICADA") {
      updateData.qualifiedAt = new Date();
    }

    if (finalStatus === "ENCERRADA" || finalStatus === "INATIVO") {
      updateData.closedAt = new Date();
      updateData.closeReason = closeReason;
      updateData.closeReasonDetail = closeReasonDetail;
    }

    // Se está reativando de INATIVO, limpar campos de fechamento
    if (lead.status === "INATIVO" && finalStatus === "PENDENTE") {
      updateData.closedAt = null;
      updateData.closeReason = null;
      updateData.closeReasonDetail = null;
    }

    const result = await prisma.$transaction(async (tx) => {
      const updatedLead = await tx.lead.update({
        where: { id: params.id },
        data: updateData,
        include: {
          company: true,
          contact: true,
          responsavel: { select: { id: true, name: true, email: true } },
        },
      });

      await tx.statusHistory.create({
        data: {
          leadId: params.id,
          previousStatus: lead.status,
          newStatus: finalStatus,
          changedById: user.id,
          reason:
            finalStatus === "ENCERRADA" || finalStatus === "INATIVO"
              ? `${closeReason}: ${closeReasonDetail ?? ""}`
              : lead.status === "INATIVO"
              ? "Lead reativado"
              : undefined,
        },
      });

      return updatedLead;
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error("Erro ao alterar status:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
