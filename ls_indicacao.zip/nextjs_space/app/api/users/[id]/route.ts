export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import bcrypt from "bcryptjs";

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "user:update")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const body = await request.json();
    const { name, email, password, role, active } = body;

    // Verifica se o email já está em uso por outro usuário
    if (email) {
      const existing = await prisma.user.findFirst({
        where: { email, id: { not: params.id } },
      });
      if (existing) {
        return NextResponse.json(
          { error: "Este email já está em uso" },
          { status: 400 }
        );
      }
    }

    const updateData: any = {};
    if (name) updateData.name = name;
    if (email) updateData.email = email;
    if (role) updateData.role = role;
    if (typeof active === "boolean") updateData.active = active;
    
    // Hash da nova senha se fornecida
    if (password && password.length >= 6) {
      updateData.passwordHash = await bcrypt.hash(password, 10);
    }

    const updated = await prisma.user.update({
      where: { id: params.id },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        active: true,
        createdAt: true,
        lastLoginAt: true,
        _count: { select: { leadsResponsible: true } },
      },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Erro ao atualizar usuário:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "user:delete")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    // Não permite excluir a si mesmo
    if (params.id === user.id) {
      return NextResponse.json(
        { error: "Você não pode excluir sua própria conta" },
        { status: 400 }
      );
    }

    // Verifica se tem leads vinculados
    const leadsCount = await prisma.lead.count({
      where: {
        OR: [
          { responsavelId: params.id },
          { registradorId: params.id },
        ],
      },
    });

    if (leadsCount > 0) {
      // Apenas desativa o usuário se tiver leads vinculados
      await prisma.user.update({
        where: { id: params.id },
        data: { active: false },
      });
      return NextResponse.json({ 
        message: "Usuário desativado (possui leads vinculados)" 
      });
    }

    // Se não tem leads, pode excluir
    await prisma.user.delete({ where: { id: params.id } });
    return NextResponse.json({ message: "Usuário excluído" });
  } catch (error) {
    console.error("Erro ao excluir usuário:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
