export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { startOfMonth, endOfMonth, subDays } from "date-fns";

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") ?? "month";

    const now = new Date();
    let startDate: Date;
    let endDate = now;

    if (period === "month") {
      startDate = startOfMonth(now);
      endDate = endOfMonth(now);
    } else if (period === "week") {
      startDate = subDays(now, 7);
    } else {
      startDate = subDays(now, 30);
    }

    // Filtros baseados no papel do usuário
    const getWhereForUser = (baseWhere: any = {}) => {
      if (user.role === "ADMIN") {
        return baseWhere;
      }
      if (user.role === "GERENTE") {
        // Gerente vê apenas leads atribuídos a ele OU prospecções próprias
        return {
          ...baseWhere,
          OR: [
            { responsavelId: user.id },
            { isProspeccao: true, registradorId: user.id }
          ]
        };
      }
      // ALIADO vê apenas leads que ele cadastrou
      return {
        ...baseWhere,
        registradorId: user.id
      };
    };

    const whereBase = getWhereForUser({
      createdAt: { gte: startDate, lte: endDate },
    });

    const [leadsCreated, pendingLeads, statusCounts, qualifiedCount, inativoCount] =
      await Promise.all([
        prisma.lead.count({ where: whereBase }),
        prisma.lead.count({ 
          where: user.role === "ADMIN" 
            ? { status: "PENDENTE" } 
            : getWhereForUser({ status: "PENDENTE" })
        }),
        prisma.lead.groupBy({
          by: ["status"],
          where: getWhereForUser({}),
          _count: { status: true },
        }),
        prisma.lead.count({
          where: getWhereForUser({ status: "QUALIFICADA" }),
        }),
        prisma.lead.count({
          where: getWhereForUser({ status: "INATIVO" }),
        }),
      ]);

    // Leads por status formatado para o funil
    const funnel = statusCounts.map((s) => ({
      status: s.status,
      count: s._count.status,
    }));

    // Taxa de conversão (qualificados / total criados no período)
    const totalForConversion = await prisma.lead.count({ where: getWhereForUser({}) });
    const conversionRate =
      totalForConversion > 0 ? Math.round((qualifiedCount / totalForConversion) * 100) : 0;

    // Leads recentes (substitui agingLeads)
    const recentLeads = await prisma.lead.findMany({
      where: getWhereForUser({}),
      include: {
        company: { select: { razaoSocial: true } },
        responsavel: { select: { name: true } },
      },
      take: 10,
      orderBy: { updatedAt: "desc" },
    });

    // Leads pendentes para atribuição (apenas Admin)
    const pendingQueue = user.role === "ADMIN" 
      ? await prisma.lead.findMany({
          where: { status: "PENDENTE", isProspeccao: false },
          include: {
            company: { select: { razaoSocial: true, cnpj: true } },
            contact: { select: { name: true, phone: true } },
            registrador: { select: { name: true } },
          },
          orderBy: { createdAt: "asc" },
          take: 10,
        })
      : [];

    return NextResponse.json({
      leadsCreated,
      pendingLeads,
      conversionRate,
      inativoCount,
      funnel,
      recentLeads,
      pendingQueue,
    });
  } catch (error) {
    console.error("Erro ao buscar estatísticas:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
