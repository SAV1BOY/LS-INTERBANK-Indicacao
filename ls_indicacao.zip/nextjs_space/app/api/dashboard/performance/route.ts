export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { startOfMonth, endOfMonth } from "date-fns";

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const user = session.user as { id: string; role: string };
    if (!hasPermission(user.role, "dashboard:team")) {
      return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
    }

    const now = new Date();
    const startDate = startOfMonth(now);
    const endDate = endOfMonth(now);

    // Buscar usuários com papel de gerente ou admin incluindo contagens
    const users = await prisma.user.findMany({
      where: {
        role: { in: ["ADMIN", "GERENTE"] },
        active: true,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        _count: {
          select: {
            leadsResponsible: {
              where: { status: { notIn: ["ENCERRADA", "INATIVO"] } },
            },
          },
        },
      },
    });

    // Buscar todos os leads dos gerentes em uma única query
    const allLeads = await prisma.lead.findMany({
      where: {
        responsavelId: { in: users.map(u => u.id) },
      },
      select: {
        responsavelId: true,
        status: true,
        assignedAt: true,
        qualifiedAt: true,
        firstContactAt: true,
      },
    });

    // Processar métricas por usuário
    const performance = users.map((u) => {
      const userLeads = allLeads.filter(l => l.responsavelId === u.id);
      
      const assigned = userLeads.filter(l => 
        l.assignedAt && l.assignedAt >= startDate && l.assignedAt <= endDate
      ).length;
      
      const qualified = userLeads.filter(l => 
        l.qualifiedAt && l.qualifiedAt >= startDate && l.qualifiedAt <= endDate
      ).length;
      
      const totalActiveLeads = u._count.leadsResponsible;

      // Calcular tempo médio de primeiro contato
      const leadsWithContact = userLeads.filter(l => 
        l.assignedAt && l.firstContactAt && 
        l.assignedAt >= startDate && l.assignedAt <= endDate
      );
      
      let avgTimeToContact = 0;
      if (leadsWithContact.length > 0) {
        const totalHours = leadsWithContact.reduce((sum, l) => {
          const diff = (l.firstContactAt!.getTime() - l.assignedAt!.getTime()) / (1000 * 60 * 60);
          return sum + diff;
        }, 0);
        avgTimeToContact = Math.round(totalHours / leadsWithContact.length);
      }

      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        leadsAssigned: assigned,
        leadsQualified: qualified,
        conversionRate: assigned > 0 ? Math.round((qualified / assigned) * 100) : 0,
        avgTimeToContact,
        totalActiveLeads,
      };
    });

    // Ordenar por taxa de conversão
    performance.sort((a, b) => b.conversionRate - a.conversionRate);

    return NextResponse.json(performance);
  } catch (error) {
    console.error("Erro ao buscar performance:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
